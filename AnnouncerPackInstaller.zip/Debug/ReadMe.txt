1. Download: 

https://drive.google.com/open?id=0B-kHaYkqfUzIN1FMMlU1OXduYTQ

2. Go to your League of Legends folder ( Default = C:/Riot Games/League of Legends )

3. Search for "Announcer_Global_Female1_VO_audio.wpk" (copy this) in the Windows search bar

4. If there is only 1 result, right click it and click open contain containing folder, if there is more than 1 result, do this and the steps 5 and 6 to all of those.

5. Rename the already existing "Announcer_Global_Female1_VO_audio.wpk" file to something like "Announcer_Global_Female1_VO_audio_old.wpk"  ATTENTION: ONLY RENAME THE SINGLE .wpk FILE! DO NOT RENAME THE OTHER .bnk FILE(S)! THIS IS THE PRIMARY REASON WHY SO MANY PEOPLE ARE REPORTING THAT THEY DO NOT HEAR ANY ANNOUNCER WHATSOEVER. So remember: only rename the one single .wpk file.

6. Move the file you downloaded in the first step into the Folder of that file.

7. Have fun!

If you get no sound even though you've done everything right, try changing the game language to english from the LoL updater(let it download). When you've done that, follow this tutorial again and it should work.